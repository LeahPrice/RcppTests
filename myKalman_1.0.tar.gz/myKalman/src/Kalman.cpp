// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
List Kalman(arma::mat F,arma::mat B,arma::mat Q,arma::mat H,arma::mat R,arma::mat z, arma::mat u, arma::colvec xinit, arma::mat Pinit) {
  unsigned int d = F.n_rows, m = z.n_rows, dimH = H.n_rows;
  
  arma::mat P = Pinit, Kal, Y = zeros<arma::mat>(m,dimH);
  arma::colvec x = xinit;
  
  for(unsigned int i=0; i<m; i++){
    //predict stage
    x = F*x + B*(u.row(i).t());
    P = F*P*F.t() + Q;
    
    //update stage
    Kal = P*H.t()*(H*P*H.t()+R).i(); // Kal is the "Kalman gain"
    x = x + Kal*(z.row(i).t()-H*x);
    P = (arma::eye<arma::mat>(d,d) - Kal*H)*P;
    
    Y.row(i) = (H*x).t();
  }
    
  List ret;
  ret["x"] = x;
  ret["P"] = P;
  ret["Y"] = Y;
  return(ret);
}
